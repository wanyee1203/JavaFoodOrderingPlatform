/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package deliveryvendor;

/**
 *
 * @author User
 */
public class Customer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Customer_1 user = new Customer_1();
        CustomerMain Customer1 = new CustomerMain(user);
        Customer1.setVisible(true);
    }
    
}
