
package deliveryvendor;

import javax.swing.*;
public class DeliveryManClass {

    
    public static void main(String[] args) {
        // TODO code application logic here
       
    }
    
}
