
package deliveryvendor;

import javax.swing.*;
public class Vendor {


    public static void main(String[] args) {
    }
    
}
